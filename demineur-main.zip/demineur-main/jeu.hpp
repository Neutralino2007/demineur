#pragma once
#include "grille.hpp"
#include <SFML/Graphics.hpp>
using namespace sf;

int partie(RenderWindow & window);
