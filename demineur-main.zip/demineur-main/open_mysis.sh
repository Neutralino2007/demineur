#!/bin/bash

# Launch the MSYS2 MinGW64 shell
/c/msys64/mingw64.exe /bin/bash -l -c "cd /c/Users/horat/OneDrive/Documents/Informatique/Programmation/cpp/demineur && exec bash"
